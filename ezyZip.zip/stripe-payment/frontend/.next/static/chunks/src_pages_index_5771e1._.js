(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_pages_index_5771e1._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_pages_index_5771e1._.js",
  "chunks": [
    "static/chunks/node_modules_next_63408d._.js",
    "static/chunks/node_modules_react-dom_82bb97._.js",
    "static/chunks/node_modules_1b7400._.js",
    "static/chunks/[root of the server]__32bfbd._.js"
  ],
  "source": "entry"
});
